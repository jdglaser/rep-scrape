class config:
    sender_email = "ses.alerts.jg@gmail.com"
    reciever_emails = ["jarred.glaser@gmail.com"]